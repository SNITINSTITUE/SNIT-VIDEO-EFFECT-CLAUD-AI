# 02 · Red Scribble (B&W Focus Callout) — Claude AI Video Effect Skill

## Description
High-contrast monochrome grayscale look with an animated hand-drawn red circle and callout arrow.

## Instructions for Claude AI
When the user uploads this ZIP package into Claude AI:
1. Ask the user to upload their **photo or video clip** (if they haven't attached one yet).
2. Embed their uploaded photo/video directly into `effect.html` as the main media source (`<img src="...">` or `<video src="...">`) using a data URL or artifact asset reference.
3. Render `effect.html` as a **full-height 9:16 interactive animated preview** inside Claude Artifacts so the user can immediately view, replay, or screen-record their edited reel.
